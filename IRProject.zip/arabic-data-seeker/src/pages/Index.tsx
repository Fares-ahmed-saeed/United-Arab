
import SearchInterface from "@/components/SearchInterface";

const Index = () => {
  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* خلفية متدرجة متحركة مع تأثيرات */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-gray-900 dark:via-purple-950 dark:to-blue-950 transition-colors animate-gradient-shift z-0">
        <div className="absolute inset-0 opacity-20 bg-subtle-pattern"></div>
      </div>
      
      {/* دوائر زخرفية متحركة بتأثيرات تدفق */}
      <div className="absolute top-20 left-10 w-64 h-64 bg-blue-300 dark:bg-blue-700 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob"></div>
      <div className="absolute top-40 right-10 w-72 h-72 bg-purple-300 dark:bg-purple-700 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000"></div>
      <div className="absolute bottom-20 left-1/4 w-80 h-80 bg-pink-300 dark:bg-pink-700 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-4000"></div>
      
      {/* عناصر تدفق إضافية */}
      <div className="absolute top-1/3 right-1/4 w-56 h-56 bg-green-300 dark:bg-green-700 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-float"></div>
      <div className="absolute bottom-1/4 right-1/3 w-48 h-48 bg-yellow-300 dark:bg-yellow-700 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-float animation-delay-2000"></div>
      
      {/* محتوى الصفحة مع تأثيرات حركية */}
      <div className="relative z-10 animate-fade-in">
        <SearchInterface />
      </div>
    </div>
  );
};

export default Index;
