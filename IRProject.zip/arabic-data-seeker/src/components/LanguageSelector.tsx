
import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { LanguagesIcon } from 'lucide-react';

export type Language = "ar" | "en" | "both";

interface LanguageSelectorProps {
  selectedLanguage: Language;
  onChange: (language: Language) => void;
}

const LanguageSelector = ({ selectedLanguage, onChange }: LanguageSelectorProps) => {
  return (
    <div className="flex items-center gap-2">
      <LanguagesIcon className="w-4 h-4 text-muted-foreground" />
      <Select
        defaultValue={selectedLanguage}
        onValueChange={(value) => onChange(value as Language)}
      >
        <SelectTrigger className="w-[180px]">
          <SelectValue placeholder="Select Language" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="ar">Arabic</SelectItem>
          <SelectItem value="en">English</SelectItem>
          <SelectItem value="both">Both Languages</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
};

export default LanguageSelector;
