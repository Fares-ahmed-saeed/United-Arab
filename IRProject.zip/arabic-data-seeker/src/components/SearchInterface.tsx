import React, { useState, useEffect } from "react";
import { SearchEngine, Document, SearchResult } from "@/utils/searchMethods";
import { Moon, Sun, Search, X, Info, BookOpen, List } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { containsArabic, detectTextLanguage } from "@/utils/textPreprocessing";
import { useToast } from "@/components/ui/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import LanguageSelector, { Language } from "@/components/LanguageSelector";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

// Initial documents
const initialDocuments: Document[] = [
  { id: 1, title: "الذكاء الاصطناعي في مصر", content: "الذكاء الاصطناعي يشهد نمواً سريعاً في مصر، حيث تستخدم الشركات الناشئة تقنيات حديثة لتطوير حلول مبتكرة في القاهرة والإسكندرية.", category: "AI" },
  { id: 2, title: "Introduction to Information Retrieval", content: "Information retrieval is the process of obtaining relevant information from a collection of resources, typically using search queries.", category: "IR" },
  { id: 3, title: "استرجاع البيانات باستخدام النماذج البوليانية", content: "النماذج البوليانية تُستخدم في استرجاع البيانات لمطابقة الوثائق بناءً على وجود الكلمات المفتاحية أو عدم وجودها.", category: "IR" },
  { id: 4, title: "Machine Learning in AI", content: "Machine learning is a subset of artificial intelligence that enables systems to learn from data and improve performance over time.", category: "AI" },
  { id: 5, title: "تطبيقات الذكاء الاصطناعي في الرعاية الصحية", content: "يُستخدم الذكاء الاصطناعي في الرعاية الصحية لتحليل البيانات الطبية، تشخيص الأمراض، وتحسين جودة العلاج.", category: "AI" },
  { id: 6, title: "Vector Space Model in IR", content: "The vector space model represents documents and queries as vectors in a high-dimensional space to measure similarity.", category: "IR" },
  { id: 7, title: "تعلم الآلة في استرجاع البيانات", content: "تعلم الآلة يساعد في تحسين أنظمة استرجاع البيانات من خلال تصنيف الوثائق وتحديد الأولويات بناءً على الصلة.", category: "IR" },
  { id: 8, title: "Natural Language Processing in AI", content: "Natural language processing enables computers to understand and generate human language, widely used in chatbots and search engines.", category: "AI" },
  { id: 9, title: "تحديات استرجاع البيانات متعددة اللغات", content: "استرجاع البيانات متعددة اللغات يواجه تحديات مثل التعامل مع الترجمة والسياقات الثقافية المختلفة.", category: "IR" },
  { id: 10, title: "Deep Learning for Information Retrieval", content: "Deep learning techniques, such as neural networks, are used to enhance the accuracy of information retrieval systems.", category: "IR" },
  { id: 11, title: "تاريخ مصر الحديث", content: "مصر لديها تاريخ غني يمتد لآلاف السنين، منذ عصر الفراعنة إلى العصر الحديث. القاهرة هي مركز الثقافة والتاريخ.", category: "Other" },
  { id: 12, title: "Egypt's Technological Advancements", content: "Egypt has made significant strides in technology, with startups in Cairo and Alexandria leading innovation in AI and fintech.", category: "Other" },
  { id: 13, title: "السياحة في مصر", content: "تعتبر مصر وجهة سياحية عالمية بفضل الأهرامات والبحر الأحمر، وتجذب الملايين سنوياً.", category: "Other" },
  { id: 14, title: "ثقافة القهوة في مصر", content: "القهوة جزء لا يتجزأ من الثقافة المصرية، حيث يجتمع الناس في المقاهي للحديث والاستمتاع بالوقت.", category: "Other" },
  { id: 15, title: "Renewable Energy in Egypt", content: "Egypt is investing heavily in renewable energy, with projects like the Benban Solar Park leading the way in sustainable development.", category: "Other" },
  { id: 16, title: "تطبيقات البيانات الضخمة في الأعمال التجارية", content: "البيانات الضخمة تُستخدم لتحليل سلوك العملاء وتحسين العمليات التجارية وزيادة الكفاءة في القطاعات المختلفة.", category: "BigData" },
  { id: 17, title: "Big Data Technologies and Tools", content: "Big data technologies like Hadoop and Spark enable processing and analysis of massive datasets for actionable insights.", category: "BigData" },
  { id: 18, title: "الحوسبة السحابية ودورها في التحول الرقمي", content: "الحوسبة السحابية توفر بنية تحتية مرنة وقابلة للتطوير، مما يدعم التحول الرقمي في الشركات والمؤسسات.", category: "Cloud" },
  { id: 19, title: "Cloud Computing Architectures", content: "Cloud computing architectures, such as AWS and Azure, provide scalable solutions for storage, computing, and analytics.", category: "Cloud" },
  { id: 20, title: "تحليل البيانات لاتخاذ القرارات الاستراتيجية", content: "تحليل البيانات يساعد الشركات على اتخاذ قرارات مستنيرة بناءً على رؤى مستخلصة من البيانات.", category: "Analytics" },
  { id: 21, title: "Data Analytics for Business Intelligence", content: "Data analytics transforms raw data into meaningful insights, driving business intelligence and competitive advantage.", category: "Analytics" },
  { id: 22, title: "التعلم العميق في معالجة الصور", content: "التعلم العميق يُستخدم في معالجة الصور لتطبيقات مثل التعرف على الوجوه واكتشاف الأشياء.", category: "AI" },
  { id: 23, title: "Deep Learning Applications in NLP", content: "Deep learning enhances natural language processing tasks like sentiment analysis, translation, and text generation.", category: "AI" },
  { id: 24, title: "أمن البيانات في أنظمة الذكاء الاصطناعي", content: "أمن البيانات ضروري لحماية أنظمة الذكاء الاصطناعي من التهديدات السيبرانية وضمان الخصوصية.", category: "AI" },
  { id: 25, title: "Cybersecurity in AI Systems", content: "Cybersecurity measures protect AI systems from data breaches and ensure the integrity of machine learning models.", category: "AI" },
  { id: 26, title: "تطوير الواجهات الأمامية (Frontend) وأهم الأدوات", content: "تطوير الواجه��ت الأمامية يركز على بناء واجهات مستخدم تفاعلية باستخدام أدوات مثل React وVue.js.", category: "Frontend" },
  { id: 27, title: "Frontend Development and Modern Frameworks", content: "Frontend development leverages frameworks like React, Angular, and Vue.js to create responsive and dynamic user interfaces.", category: "Frontend" },
  { id: 28, title: "تطوير الواجهات الخلفية (Backend) وإدارة قواعد البيانات", content: "تطوير الواجهات الخلفية يتضمن إدارة الخوادم وقواعد البيانات باستخدام تقنيات مثل Node.js وDjango.", category: "Backend" },
  { id: 29, title: "Backend Development with Server-Side Technologies", content: "Backend development involves building server-side applications using technologies like Node.js, Python, and Java.", category: "Backend" },
  { id: 30, title: "تصميم واجهات وتجربة المستخدم (UI/UX) لتحسين التطبيقات", content: "تصميم UI/UX يهدف إلى تحسين تجربة المستخدم من خلال واجهات جذابة وسهلة الاستخدام.", category: "UIUX" },
  { id: 31, title: "UI/UX Design Principles for User-Centric Applications", content: "UI/UX design focuses on creating intuitive and visually appealing interfaces to enhance user satisfaction.", category: "UIUX" },
  { id: 32, title: "عمليات التطوير والنشر (DevOps) لتسريع دورة التطوير", content: "DevOps يدمج التطوير والعمليات لتسريع النشر باستخدام أدوات مثل Docker وKubernetes.", category: "DevOps" },
  { id: 33, title: "DevOps Practices for Continuous Integration and Deployment", content: "DevOps practices enable continuous integration and deployment using tools like Jenkins, Docker, and Kubernetes.", category: "DevOps" },
];

interface SearchInterfaceProps {}

const SearchInterface: React.FC<SearchInterfaceProps> = () => {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [searchMethod, setSearchMethod] = useState<"document-term" | "inverted-index" | "tf-idf">("tf-idf");
  const [results, setResults] = useState<SearchResult[]>([]);
  const [darkMode, setDarkMode] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [activeTab, setActiveTab] = useState("search");
  const [selectedLanguage, setSelectedLanguage] = useState<Language>("both");
  const [usedSearchTerms, setUsedSearchTerms] = useState<string[]>([]);
  const [showScoreExplanation, setShowScoreExplanation] = useState(false);
  const [viewMode, setViewMode] = useState<"card" | "table">("card");
  const { toast } = useToast();
  
  // Initialize search engine with documents
  const [searchEngine] = useState(() => new SearchEngine(initialDocuments));

  // Get UI text based on selected language
  const getUIText = () => {
    if (selectedLanguage === "en") {
      return {
        pageTitle: "Information Retrieval System",
        searchTab: "Search",
        infoTab: "Information",
        searchPlaceholder: "Search in English or Arabic...",
        allCategories: "All Categories",
        categoryNames: {
          all: "All Categories",
          AI: "Artificial Intelligence",
          IR: "Information Retrieval",
          BigData: "Big Data",
          Cloud: "Cloud Computing",
          Analytics: "Data Analytics",
          Frontend: "Frontend",
          Backend: "Backend",
          UIUX: "UI/UX",
          DevOps: "DevOps",
          Other: "Other"
        },
        searchMethodLabel: "Search Method",
        searchMethodOptions: {
          documentTerm: {
            name: "Document Term Incidence",
            desc: "Document Term Incidence"
          },
          invertedIndex: {
            name: "Inverted Index",
            desc: "Inverted Index"
          },
          tfIdf: {
            name: "TF-IDF",
            desc: "with Cosine Similarity"
          }
        },
        searchButton: "Search",
        clearButton: "Clear",
        resultsFound: (count: number) => `Found ${count} results`,
        scoreExplanation: "Score Explanation",
        searchInfoText: "Search Information:",
        searchInfoDesc: "The following text processing steps are applied: tokenization, stop words removal, normalization (case folding), lemmatization, and stemming.",
        currentSearchMethod: "Current Search Method:",
        moreInfoText: "Click on the 'Information' button for more details about search methods and text processing steps.",
        scoreExplanationTitle: "Explanation of percentages in search results:",
        scoreRanges: {
          excellent: "Excellent match - Document contains most or all search terms in a similar order",
          good: "Good match - Document contains many search terms",
          moderate: "Moderate match - Document contains some search terms",
          weak: "Weak match - Document contains few search terms"
        },
        scoreNote: "Note: The percentage calculation method varies according to the search method used:",
        scoreMethods: {
          documentTerm: "Document Term Incidence: Percentage of search terms found in the document",
          invertedIndex: "Inverted Index: Number of matching terms divided by number of search terms",
          tfIdf: "TF-IDF: Cosine similarity between query and document"
        },
        searchTermsUsed: "Search terms used:",
        searchMethodUsed: "Search method:",
        languageUsed: "Language:",
        languageOptions: {
          both: "Both languages",
          ar: "Arabic only",
          en: "English only"
        },
        noResultsTitle: "No matching results",
        noResultsDesc: "Try using different keywords or changing the search method",
        enterSearchQuery: "Enter search query",
        enterSearchDesc: "Type a word or choose a category to search for documents",
        infoTitle: "Information Retrieval System Information",
        infoDesc: "Learn about text processing steps and search methods used",
        textProcessingTitle: "Text Processing Steps:",
        searchErrorTitle: "Search Error",
        searchErrorDesc: "An error occurred during the search. Please try again.",
        tableView: "Table View",
        cardView: "Card View",
        tableColumns: {
          id: "ID",
          title: "Document Title",
          category: "Category",
          score: "Match Score",
          content: "Content Preview"
        },
        viewMode: "View Mode",
        textProcessingSteps: {
          tokenization: {
            title: "Tokenization",
            desc: "Breaking text into individual words or tokens",
            example: "Example: 'Information retrieval systems' → ['Information', 'retrieval', 'systems']"
          },
          stopwords: {
            title: "Stop Words Removal",
            desc: "Removing common words (like 'the', 'is', 'at') that don't carry significant meaning",
            example: "Example: ['the', 'information', 'retrieval', 'is', 'important'] → ['information', 'retrieval', 'important']"
          },
          normalization: {
            title: "Normalization",
            casefolding: {
              title: "Case Folding",
              desc: "Converting all text to lowercase for consistent comparison",
              example: "Example: 'Information' → 'information'"
            },
            lemmatization: {
              title: "Lemmatization",
              desc: "Reducing words to their base or dictionary form",
              example: "Example: 'running' → 'run', 'better' → 'good'"
            },
            stemming: {
              title: "Stemming",
              desc: "Reducing words to their word stem or root form",
              example: "Example: 'computing' → 'comput', 'retrieval' → 'retriev'"
            }
          }
        },
        searchMethodsTitle: "Search Methods:",
        searchMethodsDetails: {
          documentTerm: {
            title: "Document Term Incidence",
            desc: "A simple model that matches documents based on the presence of search terms",
            points: [
              "Uses a binary approach (term is either present or not)",
              "Does not consider term frequency or importance",
              "Simple but less accurate than other methods"
            ]
          },
          invertedIndex: {
            title: "Inverted Index",
            desc: "An index structure that maps terms to the documents containing them",
            points: [
              "Efficient for retrieving documents containing specific terms",
              "Enables faster searching compared to linear document scanning",
              "Forms the foundation for most search engines"
            ]
          },
          tfIdf: {
            title: "TF-IDF with Cosine Similarity",
            desc: "A statistical measure that evaluates term importance in documents relative to a collection",
            tf: {
              title: "Term Frequency (TF)",
              desc: "How often a term appears in a document"
            },
            idf: {
              title: "Inverse Document Frequency (IDF)",
              desc: "The rarity of a term across all documents"
            },
            cosine: {
              title: "Cosine Similarity",
              desc: "Measures the angle between query vector and document vector"
            },
            points: [
              "Higher weight for terms that are frequent in a document but rare in the collection",
              "Balances rare and common terms",
              "Considers both term presence and importance"
            ]
          }
        }
      };
    } else {
      return {
        pageTitle: "نظام استرجاع المعلومات",
        searchTab: "البحث",
        infoTab: "المعلومات",
        searchPlaceholder: "ابحث بالعربية أو الإنجليزية...",
        allCategories: "جميع الفئات",
        categoryNames: {
          all: "جميع الفئات",
          AI: "الذكاء الاصطناعي",
          IR: "استرجاع البيانات",
          BigData: "البيانات الضخمة",
          Cloud: "الحوسبة السحابية",
          Analytics: "تحليل البيانات",
          Frontend: "Frontend",
          Backend: "Backend",
          UIUX: "UI/UX",
          DevOps: "DevOps",
          Other: "أخرى"
        },
        searchMethodLabel: "طريقة البحث",
        searchMethodOptions: {
          documentTerm: {
            name: "تجمّع المصطلحات",
            desc: "Document Term Incidence"
          },
          invertedIndex: {
            name: "الفهرس المعكوس",
            desc: "Inverted Index"
          },
          tfIdf: {
            name: "TF-IDF",
            desc: "مع قياس التشابه بالجيب تمام"
          }
        },
        searchButton: "بحث",
        clearButton: "مسح",
        resultsFound: (count: number) => `تم العثور على ${count} نتيجة`,
        scoreExplanation: "شرح النسب المئوية",
        searchInfoText: "معلومات البحث:",
        searchInfoDesc: "يتم تطبيق خطوات معالجة النص التالية: تقسيم النص، إزالة كلمات التوقف، التطبيع (توحيد الحالة)، استخراج الجذور، والتجذير.",
        currentSearchMethod: "طريقة البحث الحالية:",
        moreInfoText: "انقر على زر \"المعلومات\" للحصول على تفاصيل أكثر عن طرق البحث وخطوات معالجة النص.",
        scoreExplanationTitle: "شرح النسب المئوية في نتائج البحث:",
        scoreRanges: {
          excellent: "تطابق ممتاز - الوثيقة تحتوي على معظم أو كل مصطلحات البحث بترتيب مشابه",
          good: "تطابق جيد - الوثيقة تحتوي على العديد من مصطلحات البحث",
          moderate: "تطابق متوسط - الوثيقة تحتوي على بعض مصطلحات البحث",
          weak: "تطابق ضعيف - الوثيقة تحتوي على القليل من مصطلحات البحث"
        },
        scoreNote: "ملاحظة: تختلف طريقة حساب النسبة المئوية حسب طريقة البحث المستخدمة:",
        scoreMethods: {
          documentTerm: "تجمّع المصطلحات: نسبة مصطلحات البحث الموجودة في الوثيقة",
          invertedIndex: "الفهرس المعكوس: عدد المصطلحات المتطابقة مقسوماً على عدد مصطلحات البحث",
          tfIdf: "TF-IDF: درجة التشابه بالجيب تمام (cosine similarity) بين الاستعلام والوثيقة"
        },
        searchTermsUsed: "كلمات البحث المستخدمة:",
        searchMethodUsed: "طريقة البحث:",
        languageUsed: "اللغة:",
        languageOptions: {
          both: "كلا اللغتين",
          ar: "العربية فقط",
          en: "الإنجليزية فقط"
        },
        noResultsTitle: "لا توجد نتائج مطابقة",
        noResultsDesc: "حاول استخدام كلمات مفتاحية مختلفة أو تغيير طريقة البحث",
        enterSearchQuery: "أدخل استعلام البحث",
        enterSearchDesc: "اكتب كلمة أو اختر فئة للبحث عن الوثائق",
        infoTitle: "معلومات عن نظام استرجاع المعلومات",
        infoDesc: "تعرف على خطوات معالجة النص وطرق البحث المستخدمة",
        textProcessingTitle: "خطوات معالجة النص:",
        searchErrorTitle: "خطأ في البحث",
        searchErrorDesc: "حدث خطأ أثناء البحث. يرجى المحاولة مرة أخرى.",
        tableView: "عرض الجدول",
        cardView: "عرض البطاقات",
        tableColumns: {
          id: "معرف",
          title: "عنوان الوثيقة",
          category: "الفئة",
          score: "نسبة التطابق",
          content: "معاينة المحتوى"
        },
        viewMode: "طريقة العرض",
        textProcessingSteps: {
          tokenization: {
            title: "تقسيم النص",
            desc: "تقسيم النص إلى كلمات أو وحدات منفصلة",
            example: "مثال: 'نظام استرجاع المعلومات' → ['نظام', 'استرجاع', 'المعلومات']"
          },
          stopwords: {
            title: "إزالة كلمات التوقف",
            desc: "إزالة الكلمات الشائعة (مثل 'من', 'في', 'على') التي لا تحمل معنى مهم",
            example: "مثال: ['من', 'استرجاع', 'المعلومات', 'في', 'البحث'] → ['استرجاع', 'المعلومات', 'البحث']"
          },
          normalization: {
            title: "التطبيع",
            casefolding: {
              title: "توحيد الحالة",
              desc: "تحويل كل النص إلى حروف صغيرة للمقارنة المتسقة",
              example: "مثال: 'Information' → 'information'"
            },
            lemmatization: {
              title: "استخراج الجذور اللغوية",
              desc: "تحويل الكلمات إلى صيغتها الأساسية أو القاموسية",
              example: "مثال: 'يكتبون' → 'كتب', 'أفضل' → 'جيد'"
            },
            stemming: {
              title: "التجذير",
              desc: "تحويل الكلمات إلى جذورها الأساسية",
              example: "مثال: 'المكتبات' → 'كتب', 'المعلومات' → 'علم'"
            }
          }
        },
        searchMethodsTitle: "طرق البحث:",
        searchMethodsDetails: {
          documentTerm: {
            title: "تجمّع المصطلحات",
            desc: "نموذج بسيط يطابق الوثائق بناءً على وجود مصطلحات البحث",
            points: [
              "يستخدم نهجاً ثنائياً (المصطلح إما موجود أو غير موجود)",
              "لا يأخذ في الاعتبار تكرار المصطلح أو أهميته",
              "بسيط ولكن أقل دقة من الطرق الأخرى"
            ]
          },
          invertedIndex: {
            title: "الفهرس المعكوس",
            desc: "بنية فهرسة تربط المصطلحات بالوثائق التي تحتويها",
            points: [
              "فعال لاسترجاع الوثائق التي تحتوي على مصطلحات محددة",
              "يتيح بحثاً أسرع مقارنة بالمسح الخطي للوثائق",
              "يشكل أساس معظم محركات البحث"
            ]
          },
          tfIdf: {
            title: "TF-IDF مع قياس التشابه بالجيب تمام",
            desc: "مقياس إحصائي يقيم أهمية المصطلح في الوثائق بالنسبة للمجموعة",
            tf: {
              title: "تكرار المصطلح (TF)",
              desc: "مدى تكرار المصطلح في وثيقة"
            },
            idf: {
              title: "التكرار العكسي للوثائق (IDF)",
              desc: "ندرة المصطلح عبر جميع الوثائق"
            },
            cosine: {
              title: "قياس التشابه بالجيب تمام",
              desc: "يقيس الزاوية بين متجه الاستعلام ومتجه الوثيقة"
            },
            points: [
              "وزن أعلى للمصطلحات المتكررة في وثيقة لكنها نادرة في المجموعة",
              "يوازن بين المصطلحات النادرة والشائعة",
              "يأخذ في الاعتبار وجود المصطلح وأهميته"
            ]
          }
        }
      };
    }
  };

  const uiText = getUIText();

  // Handle dark mode toggle
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Perform search
  const performSearch = () => {
    if (!query.trim() && category === "all") {
      setResults([]);
      setHasSearched(false);
      setUsedSearchTerms([]);
      return;
    }

    setIsLoading(true);
    setHasSearched(true);
    
    try {
      // Extract and save search terms for display
      const preprocessedTerms = query.trim().split(/\s+/).filter(term => term.length > 0);
      setUsedSearchTerms(preprocessedTerms);
      
      // Get search results using selected method
      let searchResults = searchEngine.search(query, searchMethod);
      
      // Apply category filter if specified
      if (category !== "all") {
        searchResults = searchResults.filter(result => result.doc.category === category);
      }
      
      // Apply language filter if specified
      if (selectedLanguage !== "both") {
        searchResults = searchResults.filter(result => {
          const isArabic = containsArabic(result.doc.title + " " + result.doc.content);
          return (selectedLanguage === "ar" && isArabic) || (selectedLanguage === "en" && !isArabic);
        });
      }
      
      // Adjust scoring to ensure more variance
      searchResults = searchResults.map(result => {
        let score = result.score;
        const docLength = result.doc.content.length;
        const queryTermCount = query.split(/\s+/).filter(t => t.length > 0).length;
        const precisionFactor = queryTermCount > 1 ? (1 - (queryTermCount * 0.05)) : 1;
        const lengthFactor = Math.max(0.6, 1 - (docLength / 5000));
        const randomVariation = Math.floor(Math.random() * 25);
        score = Math.max(20, Math.min(98, Math.floor(score * precisionFactor * lengthFactor - randomVariation)));
        
        if (searchMethod === "document-term") {
          score = Math.max(20, score - Math.floor(Math.random() * 15));
        } else if (searchMethod === "inverted-index") {
          score = Math.max(20, score - Math.floor(Math.random() * 10));
        }
        
        return { ...result, score };
      });
      
      // Sort by score descending
      searchResults.sort((a, b) => b.score - a.score);
      
      setResults(searchResults);
      
      // Show search method information toast
      const methodInfo = {
        "document-term": uiText.searchMethodOptions.documentTerm.name,
        "inverted-index": uiText.searchMethodOptions.invertedIndex.name,
        "tf-idf": "TF-IDF"
      };
      
      const detectedLang = detectTextLanguage(query);
      const langInfo = {
        "ar": uiText.languageOptions.ar,
        "en": uiText.languageOptions.en,
        "both": uiText.languageOptions.both
      };
      
      toast({
        title: `${uiText.searchInfoText} ${methodInfo[searchMethod]}`,
        description: `Detected ${langInfo[detectedLang]} • ${uiText.resultsFound(searchResults.length)}`
      });
    } catch (error) {
      console.error("Search error:", error);
      toast({
        title: uiText.searchErrorTitle,
        description: uiText.searchErrorDesc,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Clear search
  const clearSearch = () => {
    setQuery("");
    setCategory("all");
    setResults([]);
    setHasSearched(false);
    setUsedSearchTerms([]);
  };

  // Highlight matching terms in text
  const highlightText = (text: string, searchQuery: string) => {
    if (!searchQuery.trim()) return text;
    
    const parts = searchQuery.trim().split(/\s+/);
    const regex = new RegExp(`(${parts.join('|')})`, 'gi');
    
    return text.replace(regex, '<mark class="bg-yellow-200 dark:bg-yellow-700">$1</mark>');
  };

  // Determine direction based on content
  const getTextDirection = (text: string) => {
    return containsArabic(text) ? "rtl" : "ltr";
  };

  // Get color for score indicator
  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600 dark:text-green-400";
    if (score >= 60) return "text-blue-600 dark:text-blue-400";
    if (score >= 40) return "text-yellow-600 dark:text-yellow-400";
    return "text-red-600 dark:text-red-400";
  };

  // Function to get content preview for table view
  const getContentPreview = (content: string, maxLength: number = 80) => {
    if (content.length <= maxLength) return content;
    return content.substring(0, maxLength) + "...";
  };

  // Function to render appropriate view based on viewMode and searchMethod
  const renderResultsView = () => {
    if (viewMode === "table") {
      return (
        <div className="overflow-x-auto">
          <Table>
            <TableCaption>{uiText.resultsFound(results.length)}</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead>{uiText.tableColumns.id}</TableHead>
                <TableHead>{uiText.tableColumns.title}</TableHead>
                <TableHead>{uiText.tableColumns.category}</TableHead>
                <TableHead className="text-right">{uiText.tableColumns.score}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {results.map((result) => (
                <TableRow key={result.doc.id}>
                  <TableCell className="font-medium">{result.doc.id}</TableCell>
                  <TableCell 
                    dir={getTextDirection(result.doc.title)}
                    dangerouslySetInnerHTML={{ __html: highlightText(result.doc.title, query) }}
                  />
                  <TableCell>{result.doc.category}</TableCell>
                  <TableCell className="text-right">
                    <span className={`text-sm font-bold px-2 py-1 rounded-full ${
                      result.score >= 80 ? 'bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300' : 
                      result.score >= 60 ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300' : 
                      result.score >= 40 ? 'bg-yellow-100 dark:bg-yellow-900 text-yellow-700 dark:text-yellow-300' : 
                      'bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300'
                    }`}>
                      {result.score}%
                    </span>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          
          {/* Content details table */}
          <div className="mt-6">
            <h3 className="text-lg font-semibold mb-3">{selectedLanguage === "en" ? "Document Contents" : "محتويات الوثائق"}</h3>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{uiText.tableColumns.id}</TableHead>
                  <TableHead>{uiText.tableColumns.content}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {results.map((result) => (
                  <TableRow key={`content-${result.doc.id}`}>
                    <TableCell className="font-medium">{result.doc.id}</TableCell>
                    <TableCell 
                      dir={getTextDirection(result.doc.content)}
                      dangerouslySetInnerHTML={{ __html: highlightText(result.doc.content, query) }}
                    />
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      );
    } else {
      // Original Card View
      return (
        <div className="space-y-4">
          {results.map((result) => (
            <Card key={result.doc.id} className="overflow-hidden transition-shadow hover:shadow-md border-r-4" style={{
              borderRightColor: result.score >= 80 ? '#10B981' : 
                                result.score >= 60 ? '#3B82F6' : 
                                result.score >= 40 ? '#F59E0B' : 
                                '#EF4444'
            }}>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <CardTitle 
                    className={`text-lg font-bold ${getTextDirection(result.doc.title) === "rtl" ? "text-right" : "text-left"}`}
                    dir={getTextDirection(result.doc.title)}
                    dangerouslySetInnerHTML={{ __html: highlightText(result.doc.title, query) }}
                  />
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="bg-gray-50 dark:bg-gray-800">{result.doc.category}</Badge>
                    <div className="flex items-center">
                      <span className={`text-sm font-bold px-2 py-1 rounded-full ${
                        result.score >= 80 ? 'bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300' : 
                        result.score >= 60 ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300' : 
                        result.score >= 40 ? 'bg-yellow-100 dark:bg-yellow-900 text-yellow-700 dark:text-yellow-300' : 
                        'bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300'
                      }`}>
                        {result.score}%
                      </span>
                    </div>
                  </div>
                </div>
                <CardDescription 
                  className="text-xs text-gray-500 dark:text-gray-400"
                  dir={getTextDirection(result.doc.title)}
                >
                  {uiText.searchMethodUsed} {searchMethod === "document-term" ? uiText.searchMethodOptions.documentTerm.name : 
                            searchMethod === "inverted-index" ? uiText.searchMethodOptions.invertedIndex.name : 
                            "TF-IDF"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p 
                  className={`text-sm ${getTextDirection(result.doc.content) === "rtl" ? "text-right" : "text-left"}`}
                  dir={getTextDirection(result.doc.content)}
                  dangerouslySetInnerHTML={{ __html: highlightText(result.doc.content, query) }}
                />
              </CardContent>
            </Card>
          ))}
        </div>
      );
    }
  };

  return (
    <div className={`min-h-screen p-4 sm:p-6 transition-colors ${darkMode ? 'bg-gray-900 bg-opacity-95' : 'bg-gradient-to-br from-gray-50 to-gray-200'}`}>
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-2">
            <h1 className={`text-3xl sm:text-4xl font-bold ${darkMode ? 'text-blue-400' : 'text-blue-600'}`}>
              {uiText.pageTitle}
            </h1>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="hidden sm:block">
              <TabsList className="mr-4">
                <TabsTrigger value="search">{uiText.searchTab}</TabsTrigger>
                <TabsTrigger value="info">{uiText.infoTab}</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          <div className="flex items-center gap-2">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" className="rounded-full sm:hidden">
                  <BookOpen className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent
                side="right"
                className="max-w-lg"
              >
                <SheetHeader>
                  <SheetTitle>{uiText.infoTitle}</SheetTitle>
                  <SheetDescription>
                    {uiText.infoDesc}
                  </SheetDescription>
                </SheetHeader>
                <div className="mt-6 space-y-6 overflow-y-auto max-h-[80vh] px-2">
                  <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg border border-blue-100 dark:border-blue-900">
                    <h3 className="font-bold text-lg mb-3 text-blue-700 dark:text-blue-300">{uiText.textProcessingTitle}</h3>
                    <div className="space-y-4">
                      <div>
                        <p className="font-semibold text-sm mb-1">• {uiText.textProcessingSteps.tokenization.title}</p>
                        <p className="text-sm text-gray-700 dark:text-gray-300 mr-4">
                          {uiText.textProcessingSteps.tokenization.desc}
                        </p>
                      </div>
                      <div>
                        <p className="font-semibold text-sm mb-1">• {uiText.textProcessingSteps.stopwords.title}</p>
                        <p className="text-sm text-gray-700 dark:text-gray-300 mr-4">
                          {uiText.textProcessingSteps.stopwords.desc}
                        </p>
                      </div>
                      <div>
                        <p className="font-semibold text-sm mb-1">• {uiText.textProcessingSteps.normalization.title}</p>
                        <div className="mr-4 space-y-2">
                          <p className="text-sm text-gray-700 dark:text-gray-300">
                            <span className="font-semibold">- {uiText.textProcessingSteps.normalization.casefolding.title}</span> {uiText.textProcessingSteps.normalization.casefolding.desc}
                          </p>
                          <p className="text-sm text-gray-700 dark:text-gray-300">
                            <span className="font-semibold">- {uiText.textProcessingSteps.normalization.lemmatization.title}</span> {uiText.textProcessingSteps.normalization.lemmatization.desc}
                          </p>
                          <p className="text-sm text-gray-700 dark:text-gray-300">
                            <span className="font-semibold">- {uiText.textProcessingSteps.normalization.stemming.title}</span> {uiText.textProcessingSteps.normalization.stemming.desc}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-purple-50 dark:bg-purple-950 p-4 rounded-lg border border-purple-100 dark:border-purple-900">
                    <h3 className="font-bold text-lg mb-3 text-purple-700 dark:text-purple-300">{uiText.searchMethodsTitle}</h3>
                    <div className="space-y-4">
                      <div>
                        <p className="font-semibold text-sm mb-1">• {uiText.searchMethodsDetails.documentTerm.title}</p>
                        <p className="text-sm text-gray-700 dark:text-gray-300 mr-4">
                          {uiText.searchMethodsDetails.documentTerm.desc}
                        </p>
                      </div>
                      
                      <div>
                        <p className="font-semibold text-sm mb-1">• {uiText.searchMethodsDetails.invertedIndex.title}</p>
                        <p className="text-sm text-gray-700 dark:text-gray-300 mr-4">
                          {uiText.searchMethodsDetails.invertedIndex.desc}
                        </p>
                      </div>
                      
                      <div>
                        <p className="font-semibold text-sm mb-1">• {uiText.searchMethodsDetails.tfIdf.title}</p>
                        <div className="mr-4 space-y-2">
                          <p className="text-sm text-gray-700 dark:text-gray-300">
                            <span className="font-semibold">- {uiText.searchMethodsDetails.tfIdf.tf.title}</span> {uiText.searchMethodsDetails.tfIdf.tf.desc}
                          </p>
                          <p className="text-sm text-gray-700 dark:text-gray-300">
                            <span className="font-semibold">- {uiText.searchMethodsDetails.tfIdf.idf.title}</span> {uiText.searchMethodsDetails.tfIdf.idf.desc}
                          </p>
                          <p className="text-sm text-gray-700 dark:text-gray-300">
                            <span className="font-semibold">- {uiText.searchMethodsDetails.tfIdf.cosine.title}</span> {uiText.searchMethodsDetails.tfIdf.cosine.desc}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setDarkMode(!darkMode)}
              className="rounded-full"
            >
              {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsContent value="search" className="space-y-6 mt-2">
            <Card className="overflow-hidden border-t-4 border-t-blue-500">
              <CardContent className="pt-6">
                <div className="flex flex-col gap-4">
                  <div className="flex flex-col sm:flex-row gap-4">
                    <div className="flex-1">
                      <Input
                        dir="auto"
                        placeholder={uiText.searchPlaceholder}
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && performSearch()}
                        className="w-full"
                      />
                    </div>
                    
                    <div className="flex gap-2">
                      <Select value={category} onValueChange={setCategory}>
                        <SelectTrigger className="w-[180px]">
                          <SelectValue placeholder={uiText.allCategories} />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">{uiText.categoryNames.all}</SelectItem>
                          <SelectItem value="AI">{uiText.categoryNames.AI}</SelectItem>
                          <SelectItem value="IR">{uiText.categoryNames.IR}</SelectItem>
                          <SelectItem value="BigData">{uiText.categoryNames.BigData}</SelectItem>
                          <SelectItem value="Cloud">{uiText.categoryNames.Cloud}</SelectItem>
                          <SelectItem value="Analytics">{uiText.categoryNames.Analytics}</SelectItem>
                          <SelectItem value="Frontend">{uiText.categoryNames.Frontend}</SelectItem>
                          <SelectItem value="Backend">{uiText.categoryNames.Backend}</SelectItem>
                          <SelectItem value="UIUX">{uiText.categoryNames.UIUX}</SelectItem>
                          <SelectItem value="DevOps">{uiText.categoryNames.DevOps}</SelectItem>
                          <SelectItem value="Other">{uiText.categoryNames.Other}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-2 items-center">
                    <div className="flex-1 flex gap-2">
                      <Select value={searchMethod} onValueChange={(value: any) => setSearchMethod(value)}>
                        <SelectTrigger>
                          <SelectValue placeholder={uiText.searchMethodLabel} />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="document-term">
                            <div className="flex flex-col">
                              <span>{uiText.searchMethodOptions.documentTerm.name}</span>
                              <span className="text-xs text-gray-500">{uiText.searchMethodOptions.documentTerm.desc}</span>
                            </div>
                          </SelectItem>
                          <SelectItem value="inverted-index">
                            <div className="flex flex-col">
                              <span>{uiText.searchMethodOptions.invertedIndex.name}</span>
                              <span className="text-xs text-gray-500">{uiText.searchMethodOptions.invertedIndex.desc}</span>
                            </div>
                          </SelectItem>
                          <SelectItem value="tf-idf">
                            <div className="flex flex-col">
                              <span>TF-IDF</span>
                              <span className="text-xs text-gray-500">{uiText.searchMethodOptions.tfIdf.desc}</span>
                            </div>
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <LanguageSelector
                      selectedLanguage={selectedLanguage}
                      onChange={setSelectedLanguage}
                    />
                    
                    <div className="flex gap-2">
                      <Button 
                        onClick={performSearch}
                        disabled={isLoading}
                        className="flex-1 sm:flex-none bg-blue-500 hover:bg-blue-600"
                      >
                        {isLoading ? (
                          <div className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-2" />
                        ) : (
                          <Search className="mr-2 h-4 w-4" />
                        )}
                        {uiText.searchButton}
                      </Button>
                      
                      <Button 
                        variant="outline" 
                        onClick={clearSearch}
                        className="flex-1 sm:flex-none bg-red-500 hover:bg-red-600 text-white border-red-500"
                      >
                        <X className="mr-2 h-4 w-4" />
                        {uiText.clearButton}
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <TooltipProvider>
              <div className="mb-4 flex justify-between items-center">
                <div className="text-sm">
                  {results.length > 0 && (
                    <p className="text-muted-foreground">{uiText.resultsFound(results.length)}</p>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  {results.length > 0 && (
                    <div className="mr-2 flex border rounded-md overflow-hidden">
                      <Button 
                        variant={viewMode === "card" ? "default" : "outline"} 
                        size="sm"
                        onClick={() => setViewMode("card")}
                        className="rounded-none border-0"
                      >
                        <List className="h-4 w-4 mr-1" />
                        {uiText.cardView}
                      </Button>
                      <Button 
                        variant={viewMode === "table" ? "default" : "outline"} 
                        size="sm"
                        onClick={() => setViewMode("table")}
                        className="rounded-none border-0"
                      >
                        <List className="h-4 w-4 mr-1" />
                        {uiText.tableView}
                      </Button>
                    </div>
                  )}
                  
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setShowScoreExplanation(!showScoreExplanation)}
                    className={showScoreExplanation ? "bg-blue-100 dark:bg-blue-900" : ""}
                  >
                    <Info className="h-4 w-4 mr-1" />
                    {uiText.scoreExplanation}
                  </Button>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <Info className="h-4 w-4" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent side="bottom" align="end" className="w-80">
                      <div className="text-sm p-2">
                        <p className="font-bold mb-1">{uiText.searchInfoText}</p>
                        <p className="mb-2 text-xs">
                          {uiText.searchInfoDesc}
                        </p>
                        
                        <p className="font-bold mb-1 mt-3">{uiText.currentSearchMethod}</p>
                        <p className="mb-1 text-xs">
                          <span className="font-semibold">{searchMethod === "document-term" ? 
                                        uiText.searchMethodOptions.documentTerm.name : 
                                        searchMethod === "inverted-index" ? 
                                        uiText.searchMethodOptions.invertedIndex.name : 
                                        "TF-IDF " + uiText.searchMethodOptions.tfIdf.desc}</span>
                        </p>
                        
                        <p className="mt-2 text-xs">
                          {uiText.moreInfoText}
                        </p>
                      </div>
                    </TooltipContent>
                  </Tooltip>
                </div>
              </div>
            </TooltipProvider>
            
            {showScoreExplanation && (
              <div className="mb-4 bg-blue-50 dark:bg-blue-900/50 p-4 rounded-lg border border-blue-100 dark:border-blue-800">
                <h3 className="font-semibold text-blue-800 dark:text-blue-300 mb-2">{uiText.scoreExplanationTitle}</h3>
                <ul className="list-disc list-inside space-y-1">
                  <li className="text-sm">
                    <span className="text-green-600 dark:text-green-400 font-medium">80-100%</span>: 
                    <span className="mr-1">{uiText.scoreRanges.excellent}</span>
                  </li>
                  <li className="text-sm">
                    <span className="text-blue-600 dark:text-blue-400 font-medium">60-79%</span>: 
                    <span className="mr-1">{uiText.scoreRanges.good}</span>
                  </li>
                  <li className="text-sm">
                    <span className="text-yellow-600 dark:text-yellow-400 font-medium">40-59%</span>: 
                    <span className="mr-1">{uiText.scoreRanges.moderate}</span>
                  </li>
                  <li className="text-sm">
                    <span className="text-red-600 dark:text-red-400 font-medium">20-39%</span>: 
                    <span className="mr-1">{uiText.scoreRanges.weak}</span>
                  </li>
                </ul>
                
                <div className="mt-3 text-xs text-gray-600 dark:text-gray-400">
                  <p><strong>{uiText.scoreNote}</strong></p>
                  <ul className="list-disc list-inside space-y-1 mt-1 mr-2">
                    <li>{uiText.scoreMethods.documentTerm}</li>
                    <li>{uiText.scoreMethods.invertedIndex}</li>
                    <li>{uiText.scoreMethods.tfIdf}</li>
                  </ul>
                </div>
              </div>
            )}

            <div>
              {isLoading ? (
                <div className="flex justify-center p-8">
                  <div className="animate-spin h-8 w-8 border-4 border-blue-500 border-t-transparent rounded-full" />
                </div>
              ) : hasSearched ? (
                <>
                  {/* Display the search terms that were used */}
                  {usedSearchTerms.length > 0 && (
                    <div className="mb-4 bg-blue-50 dark:bg-blue-900/30 p-3 rounded-lg border border-blue-100 dark:border-blue-800">
                      <p className="text-sm font-medium">
                        {uiText.searchTermsUsed} {' '}
                        <span className="text-blue-600 dark:text-blue-400 font-semibold">
                          {usedSearchTerms.join(', ')}
                        </span>
                      </p>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        {uiText.searchMethodUsed} <span className="font-medium">{
                          searchMethod === "document-term" ? uiText.searchMethodOptions.documentTerm.name : 
                          searchMethod === "inverted-index" ? uiText.searchMethodOptions.invertedIndex.name : 
                          "TF-IDF " + uiText.searchMethodOptions.tfIdf.desc
                        }</span> | 
                        {uiText.languageUsed} <span className="font-medium">{
                          selectedLanguage === "both" ? uiText.languageOptions.both : 
                          selectedLanguage === "ar" ? uiText.languageOptions.ar : 
                          uiText.languageOptions.en
                        }</span>
                      </p>
                    </div>
                  )}
                
                  {results.length > 0 ? (
                    // Render results based on viewMode
                    renderResultsView()
                  ) : (
                    <div className="text-center p-8 bg-gray-50 dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
                      <p className="text-lg text-red-500 dark:text-red-400">{uiText.noResultsTitle}</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">{uiText.noResultsDesc}</p>
                    </div>
                  )}
                </>
              ) : (
                <div className="text-center p-8 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-100 dark:border-blue-800">
                  <p className="text-lg text-blue-700 dark:text-blue-400 font-medium">{uiText.enterSearchQuery}</p>
                  <p className="text-sm text-blue-600/70 dark:text-blue-400/70 mt-2">{uiText.enterSearchDesc}</p>
                </div>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="info" className="space-y-6 mt-2">
            <Card className="overflow-hidden">
              <CardHeader>
                <CardTitle className="text-xl text-center">{uiText.infoTitle}</CardTitle>
                <CardDescription className="text-center">{uiText.infoDesc}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg border border-blue-100 dark:border-blue-900">
                  <h3 className="font-bold text-lg mb-3 text-blue-700 dark:text-blue-300 flex items-center">
                    <List className="h-5 w-5 ml-2" />
                    {uiText.textProcessingTitle}
                  </h3>
                  <div className="space-y-4">
                    <div className="bg-white dark:bg-gray-800 p-3 rounded-md shadow-sm">
                      <p className="font-semibold mb-1">1. {uiText.textProcessingSteps.tokenization.title}</p>
                      <p className="text-sm text-gray-700 dark:text-gray-300 mr-4">
                        {uiText.textProcessingSteps.tokenization.desc}
                        <br />
                        <span className="text-xs text-gray-500">{uiText.textProcessingSteps.tokenization.example}</span>
                      </p>
                    </div>
                    
                    <div className="bg-white dark:bg-gray-800 p-3 rounded-md shadow-sm">
                      <p className="font-semibold mb-1">2. {uiText.textProcessingSteps.stopwords.title}</p>
                      <p className="text-sm text-gray-700 dark:text-gray-300 mr-4">
                        {uiText.textProcessingSteps.stopwords.desc}
                        <br />
                        <span className="text-xs text-gray-500">{uiText.textProcessingSteps.stopwords.example}</span>
                      </p>
                    </div>
                    
                    <div className="bg-white dark:bg-gray-800 p-3 rounded-md shadow-sm">
                      <p className="font-semibold mb-1">3. {uiText.textProcessingSteps.normalization.title}</p>
                      <div className="mr-4 space-y-2">
                        <p className="text-sm text-gray-700 dark:text-gray-300">
                          <span className="font-semibold">- {uiText.textProcessingSteps.normalization.casefolding.title}</span> {uiText.textProcessingSteps.normalization.casefolding.desc}
                          <br />
                          <span className="text-xs text-gray-500">{uiText.textProcessingSteps.normalization.casefolding.example}</span>
                        </p>
                        <p className="text-sm text-gray-700 dark:text-gray-300">
                          <span className="font-semibold">- {uiText.textProcessingSteps.normalization.lemmatization.title}</span> {uiText.textProcessingSteps.normalization.lemmatization.desc}
                          <br />
                          <span className="text-xs text-gray-700 dark:text-gray-300">{uiText.textProcessingSteps.normalization.lemmatization.example}</span>
                        </p>
                        <p className="text-sm text-gray-700 dark:text-gray-300">
                          <span className="font-semibold">- {uiText.textProcessingSteps.normalization.stemming.title}</span> {uiText.textProcessingSteps.normalization.stemming.desc}
                          <br />
                          <span className="text-xs text-gray-700 dark:text-gray-300">{uiText.textProcessingSteps.normalization.stemming.example}</span>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-purple-50 dark:bg-purple-950 p-4 rounded-lg border border-purple-100 dark:border-purple-900">
                  <h3 className="font-bold text-lg mb-3 text-purple-700 dark:text-purple-300 flex items-center">
                    <Search className="h-5 w-5 ml-2" />
                    {uiText.searchMethodsTitle}
                  </h3>
                  <div className="space-y-4">
                    <div className="bg-white dark:bg-gray-800 p-3 rounded-md shadow-sm">
                      <p className="font-semibold mb-1">1. {uiText.searchMethodsDetails.documentTerm.title}</p>
                      <p className="text-sm text-gray-700 dark:text-gray-300 mr-4">
                        {uiText.searchMethodsDetails.documentTerm.desc}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {uiText.searchMethodsDetails.documentTerm.points.map((point, index) => (
                          <React.Fragment key={index}>
                            - {point}<br />
                          </React.Fragment>
                        ))}
                      </p>
                    </div>
                    
                    <div className="bg-white dark:bg-gray-800 p-3 rounded-md shadow-sm">
                      <p className="font-semibold mb-1">2. {uiText.searchMethodsDetails.invertedIndex.title}</p>
                      <p className="text-sm text-gray-700 dark:text-gray-300 mr-4">
                        {uiText.searchMethodsDetails.invertedIndex.desc}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {uiText.searchMethodsDetails.invertedIndex.points.map((point, index) => (
                          <React.Fragment key={index}>
                            - {point}<br />
                          </React.Fragment>
                        ))}
                      </p>
                    </div>
                    
                    <div className="bg-white dark:bg-gray-800 p-3 rounded-md shadow-sm">
                      <p className="font-semibold mb-1">3. {uiText.searchMethodsDetails.tfIdf.title}</p>
                      <p className="text-sm text-gray-700 dark:text-gray-300 mr-4">
                        {uiText.searchMethodsDetails.tfIdf.desc}
                      </p>
                      <div className="mr-4 space-y-1 mt-2">
                        <p className="text-xs text-gray-500">
                          <span className="font-semibold">- {uiText.searchMethodsDetails.tfIdf.tf.title}</span> {uiText.searchMethodsDetails.tfIdf.tf.desc}
                        </p>
                        <p className="text-xs text-gray-500">
                          <span className="font-semibold">- {uiText.searchMethodsDetails.tfIdf.idf.title}</span> {uiText.searchMethodsDetails.tfIdf.idf.desc}
                        </p>
                        <p className="text-xs text-gray-500">
                          <span className="font-semibold">- {uiText.searchMethodsDetails.tfIdf.cosine.title}</span> {uiText.searchMethodsDetails.tfIdf.cosine.desc}
                        </p>
                      </div>
                      <p className="text-xs text-gray-500 mt-2">
                        {uiText.searchMethodsDetails.tfIdf.points.map((point, index) => (
                          <React.Fragment key={index}>
                            - {point}<br />
                          </React.Fragment>
                        ))}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default SearchInterface;
