// Text preprocessing utilities for information retrieval

// Stop words lists
const arabicStopWords = [
  "من", "إلى", "عن", "على", "في", "هذا", "هذه", "تلك", "ذلك", "هو", "هي", "هم", "هن",
  "أنت", "أنتم", "أنتن", "أنا", "نحن", "كان", "كانت", "يكون", "تكون", "الذي", "التي", "الذين",
  "ما", "ماذا", "كيف", "متى", "أين", "لماذا", "هل", "إذا", "إذ", "لا", "لم", "لن", "لو",
  "إن", "أن", "و", "أو", "ثم", "بل", "لكن", "مع", "عند", "عندما", "منذ", "حتى", "قد", "فقد",
  "كل", "بعض", "غير", "أكثر", "بين", "حول", "ضد", "خلال", "بعد", "قبل", "تحت", "فوق", "يمكن",
  "نفس", "حيث", "الآن", "هنا", "هناك", "فقط", "ثم", "إلا", "أيضا", "جدا", "حسب", "عندئذ"
];

const englishStopWords = [
  "a", "an", "the", "and", "or", "but", "in", "on", "at", "to", "for", "with", "by", "about",
  "as", "is", "are", "was", "were", "be", "been", "being", "have", "has", "had", "do", "does",
  "did", "will", "would", "shall", "should", "may", "might", "must", "can", "could", "of", "from",
  "this", "that", "these", "those", "it", "its", "they", "them", "their", "he", "him", "his", "she",
  "her", "we", "us", "you", "your", "i", "my", "me", "myself", "through", "during", "before", "after",
  "above", "below", "between", "into", "over", "under", "again", "further", "then", "once", "here",
  "there", "when", "where", "why", "how", "all", "any", "both", "each", "few", "more", "most",
  "other", "some", "such", "no", "nor", "not", "only", "own", "same", "so", "than", "too", "very"
];

/**
 * Enhanced Arabic stemmer - implements stemming for Arabic text
 * Stemming is the process of reducing words to their word stem or root form
 */
const arabicStemmer = (word: string): string => {
  // Remove common prefixes (simplified version)
  const prefixes = ["ال", "و", "ف", "ب", "ك", "ل", "لل", "بال", "كال", "فال", "وال", "وب", "فب", "ول"];
  let stemmed = word;
  
  for (const prefix of prefixes) {
    if (stemmed.startsWith(prefix) && stemmed.length > prefix.length + 2) {
      stemmed = stemmed.substring(prefix.length);
      break;
    }
  }
  
  // Remove common suffixes (enhanced version)
  const suffixes = [
    "ون", "ات", "ين", "ان", "تن", "تم", "نا", "ها", "ية", "هم", "هن", "ي", "ه", "ت", 
    "ة", "تان", "تين", "وا", "يا", "تا", "ني", "كم", "هما", "تما", "كما", "تيه", "تك"
  ];
  
  for (const suffix of suffixes) {
    if (stemmed.endsWith(suffix) && stemmed.length > suffix.length + 2) {
      stemmed = stemmed.substring(0, stemmed.length - suffix.length);
      break;
    }
  }
  
  return stemmed;
};

/**
 * Enhanced English stemmer with better handling of irregular forms
 * This is a more comprehensive Porter-like stemming implementation
 */
const englishStemmer = (word: string): string => {
  // First ensure the word is lowercase
  let stemmed = word.toLowerCase();
  
  // Handle specific irregular plurals
  const irregularPlurals: Record<string, string> = {
    "children": "child", "men": "man", "women": "woman", "mice": "mouse",
    "people": "person", "teeth": "tooth", "feet": "foot", "geese": "goose",
    "leaves": "leaf", "lives": "life", "knives": "knife", "wives": "wife"
  };
  
  if (irregularPlurals[stemmed]) {
    return irregularPlurals[stemmed];
  }
  
  // Handle plurals and past tense
  if (stemmed.endsWith('ies') && stemmed.length > 3) {
    stemmed = stemmed.slice(0, -3) + 'y';
  } else if (/[aeiou]/.test(stemmed.slice(-3, -2)) && stemmed.endsWith('es') && stemmed.length > 3) {
    stemmed = stemmed.slice(0, -1);
  } else if (stemmed.endsWith('es') && !stemmed.endsWith('ses') && !stemmed.endsWith('zes') && stemmed.length > 2) {
    stemmed = stemmed.slice(0, -2);
  } else if (stemmed.endsWith('s') && !stemmed.endsWith('ss') && !stemmed.endsWith('us') && !stemmed.endsWith('is') && stemmed.length > 2) {
    stemmed = stemmed.slice(0, -1);
  }
  
  // Handle common verb endings
  if (stemmed.endsWith('ing')) {
    const base = stemmed.slice(0, -3);
    if (base.length >= 2) {
      if (base.endsWith('e')) {
        stemmed = base;
      } else if (base.length > 1 && /[aeiou]/.test(base.slice(-2, -1)) && /[^aeiou]/.test(base.slice(-1))) {
        stemmed = base + base.slice(-1);
      } else {
        stemmed = base;
      }
    }
  } else if (stemmed.endsWith('ed') && !stemmed.endsWith('eed')) {
    const base = stemmed.slice(0, -2);
    if (base.length >= 2) {
      if (base.endsWith('e')) {
        stemmed = base;
      } else if (base.length > 1 && /[aeiou]/.test(base.slice(-2, -1)) && /[^aeiou]/.test(base.slice(-1))) {
        stemmed = base + base.slice(-1);
      } else {
        stemmed = base;
      }
    }
  }
  
  // Handle other common endings
  if (stemmed.endsWith('ly') && stemmed.length > 2) {
    stemmed = stemmed.slice(0, -2);
  } else if (stemmed.endsWith('ful') && stemmed.length > 3) {
    stemmed = stemmed.slice(0, -3);
  }
  
  return stemmed;
};

/**
 * Enhanced lemmatization function with more comprehensive dictionary
 * Lemmatization is the process of reducing words to their base or dictionary form
 */
const englishLemmatizer = (word: string): string => {
  // More comprehensive lemmatization dictionary
  const lemmaDict: Record<string, string> = {
    // BE verbs
    "am": "be", "is": "be", "are": "be", "was": "be", "were": "be", "being": "be", "been": "be",
    
    // HAVE verbs
    "has": "have", "having": "have",
    
    // DO verbs
    "does": "do", "did": "do", "doing": "do",
    
    // Common irregular verbs
    "goes": "go", "went": "go", "gone": "go", "going": "go",
    "makes": "make", "made": "make", "making": "make",
    "takes": "take", "took": "take", "taken": "take", "taking": "take",
    "comes": "come", "came": "come", "coming": "come",
    "sees": "see", "saw": "see", "seen": "see", "seeing": "see",
    "thinks": "think", "thought": "think", "thinking": "think",
    "says": "say", "said": "say", "saying": "say",
    "knows": "know", "knew": "know", "known": "know", "knowing": "know",
    "finds": "find", "found": "find", "finding": "find",
    "gets": "get", "got": "get", "getting": "get",
    "gives": "give", "gave": "give", "given": "give", "giving": "give",
    "tells": "tell", "told": "tell", "telling": "tell",
    "works": "work", "worked": "work", "working": "work",
    "calls": "call", "called": "call", "calling": "call",
    "tries": "try", "tried": "try", "trying": "try",
    "asks": "ask", "asked": "ask", "asking": "ask",
    "needs": "need", "needed": "need", "needing": "need",
    "feels": "feel", "felt": "feel", "feeling": "feel",
    "becomes": "become", "became": "become", "becoming": "become",
    "leaves": "leave", "left": "leave", "leaving": "leave",
    "puts": "put", "putting": "put",
    "means": "mean", "meant": "mean", "meaning": "mean",
    "keeps": "keep", "kept": "keep", "keeping": "keep",
    "lets": "let", "letting": "let",
    // Nouns
    "children": "child", "men": "man", "women": "woman", "people": "person",
    "mice": "mouse", "teeth": "tooth", "feet": "foot", "geese": "goose",
    "lives": "life", "wives": "wife", "knives": "knife",
    "shelves": "shelf", "selves": "self", "thieves": "thief", "loaves": "loaf"
  };
  
  const lowerWord = word.toLowerCase();
  return lemmaDict[lowerWord] || lowerWord;
};

/**
 * Tokenize text into words (Tokenization)
 * Converts a string of text into an array of individual tokens
 */
export const tokenize = (text: string): string[] => {
  // Split by spaces and punctuation, handling both Arabic and English
  return text.split(/[\s.,;:!?"'()\[\]{}\/\\<>+\-*=%#@&|~`^]+/)
    .filter(token => token.length > 0); // Remove empty tokens
};

/**
 * Remove stop words from token list (Stop word removal)
 * Stop words are common words that don't add much meaning
 */
export const removeStopWords = (tokens: string[], language: "ar" | "en" | "both" = "both"): string[] => {
  const stopWords = 
    language === "ar" ? arabicStopWords : 
    language === "en" ? englishStopWords : 
    [...arabicStopWords, ...englishStopWords];
  
  return tokens.filter(token => !stopWords.includes(token.toLowerCase()));
};

/**
 * Normalize tokens - implements case folding
 * Case folding converts all text to lowercase for consistent comparison
 */
export const normalizeTokens = (tokens: string[]): string[] => {
  return tokens.map(token => token.toLowerCase());
};

/**
 * Apply lemmatization to tokens
 */
export const applyLemmatization = (tokens: string[]): string[] => {
  return tokens.map(token => {
    const isArabic = /[\u0600-\u06FF]/.test(token);
    // Currently only supporting English lemmatization
    return isArabic ? token : englishLemmatizer(token);
  });
};

/**
 * Apply stemming based on language detection
 * Uses appropriate stemmer based on detected language
 */
export const applyStems = (tokens: string[]): string[] => {
  return tokens.map(token => {
    // Simple language detection
    const isArabic = /[\u0600-\u06FF]/.test(token);
    return isArabic ? arabicStemmer(token) : englishStemmer(token);
  });
};

/**
 * Full text preprocessing pipeline
 * Implements tokenization -> normalization -> stop word removal -> lemmatization -> stemming
 */
export const preprocessText = (text: string, language: "ar" | "en" | "both" = "both"): string[] => {
  const tokens = tokenize(text);
  const normalized = normalizeTokens(tokens);
  const withoutStopWords = removeStopWords(normalized, language);
  const lemmatized = applyLemmatization(withoutStopWords);
  const stemmed = applyStems(lemmatized);
  return stemmed;
};

/**
 * Detect if text contains Arabic characters
 */
export const containsArabic = (text: string): boolean => {
  return /[\u0600-\u06FF]/.test(text);
};

/**
 * Get language based on text content
 */
export const detectTextLanguage = (text: string): "ar" | "en" | "both" => {
  const hasArabic = /[\u0600-\u06FF]/.test(text);
  const hasEnglish = /[a-zA-Z]/.test(text);
  
  if (hasArabic && hasEnglish) return "both";
  if (hasArabic) return "ar";
  return "en";
};
